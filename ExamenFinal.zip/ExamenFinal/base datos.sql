CREATE DATABASE registroagenda1;
USE registroagenda1;